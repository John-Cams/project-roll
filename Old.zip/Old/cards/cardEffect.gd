class_name CardEffect extends Resource

static func flipACoin(heads:Callable, tails: Callable):
	print("I'm flipping out XD")
	if(randi_range(0,1)==0):
		heads.call()
	else:
		tails.call()
	
static func changeType(context:Array):
	var dice = context[0]
	var side = context[1]
	var type = context[2]
	dice.types[side] = type
	
static func changeMult(context:Array):
	var dice = context[0]
	var side = context[1]
	var mult = context[2]
	dice.mult[side] = mult

static func changeVal(context:Array):
	var dice = context[0]
	var side = context[1]
	var add = context[2]
	dice.vals[side] = add

static func combine(callables: Array[Callable], context:Array):
	for function in callables:
		function.call(context)
