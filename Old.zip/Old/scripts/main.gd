extends Control

var effect:CardEffect = CardEffect.new() 
var currentTray = 0
var cardTrays:Array[Control]

func _ready():
	await get_tree().process_frame  # ensure dice _ready runs first
	
	for dice in Global.dice:
		dice.doneRolling.connect(_on_dice_roll_finished)
		
	cardTrays.append($CardTray)
	cardTrays.append($CardTray2)
	
	for item in cardTrays:
		item.visible = false
	cardTrays[currentTray].visible = true
	
	
func _process(delta):
	if Input.is_action_just_pressed("space"):
		print("Wa")
		for dice in Global.dice:
			dice.roll()
		
func _on_dice_roll_finished():
	for tray in Global.cardTrays:
		tray.afterRoll()
	print("run")
	


func _on_button_pressed() -> void:
	currentTray += 1
	if(currentTray == cardTrays.size()):
		currentTray = 0
	for item in cardTrays:
		item.visible = false
		for card in item.cards:
			if card != null:
				card.visible = false
	cardTrays[currentTray].visible = true
	for card in cardTrays[currentTray].cards:
		if card != null:
			card.visible = true
