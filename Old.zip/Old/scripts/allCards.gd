extends Node

var	 CARD_DEFS:Dictionary = {
	"Add One":{
		"description": "Adds one", 
		"quote" : "Addition is adding", 
		"color" : Color(0.661, 0.842, 0.993, 1.0), 
		"effect" : Callable(CardEffect, "changeVal")
	}
}
