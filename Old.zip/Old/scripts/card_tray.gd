extends Control

@export var dice:Dice

@export var cards = []

func _ready() -> void:
	$ColorRect.color = dice.color
	Global.cardTrays.append(self)

func _process(delta: float) -> void:
	cards = [
		$CardSlot.getCard(),
		$CardSlot.getCard(),
		$CardSlot.getCard(),
		$CardSlot.getCard(),
		$CardSlot.getCard(),
		$CardSlot.getCard()]

func afterRoll():
	print("Running")
	
	var value = dice.val
	if cards[value-1] == null:
		print(value + dice.vals[value])
		print("Nothing")
		return
		
	var effect = AllCards.CARD_DEFS.get($CardSlot.currentCard.getCardID())["effect"]
	effect.call([dice,value,1])
	print(value + dice.vals[value])
	
	
	
